"""Stream audio to the ASR service over WebSocket and print live results.

    pip install websockets numpy soundfile
    python asr_stream.py speech.wav --language hi                # as if it were a live mic
    python asr_stream.py call.wav --language ta --sample-rate 8000   # telephone-rate audio

The file is sent in 20 ms frames at real-time pace. The server finds the
utterances itself (VAD): you get `partial` text while someone talks and a
`final` transcript after each pause. Replace `read_frames()` with your
microphone or telephony feed; nothing else changes.
"""
import argparse
import asyncio
import json
import time

import numpy as np
import soundfile as sf
import websockets

ASR_WS = "ws://localhost:8001/v1/stream"


def read_frames(path, sample_rate, frame_ms=20):
    """Yield 16-bit PCM frames of the file, resampled to `sample_rate` if needed."""
    audio, sr = sf.read(path, dtype="float32", always_2d=True)
    audio = audio.mean(axis=1)
    if sr != sample_rate:                       # simple resample, fine for a demo
        n = int(len(audio) * sample_rate / sr)
        audio = np.interp(np.linspace(0, len(audio) - 1, n), np.arange(len(audio)), audio)
    audio = np.concatenate([audio, np.zeros(sample_rate)])   # 1 s of silence ends the last utterance
    pcm = (np.clip(audio, -1, 1) * 32767).astype("<i2")
    step = sample_rate * frame_ms // 1000
    for i in range(0, len(pcm), step):
        yield pcm[i: i + step].tobytes()


async def main(a):
    query = f"language={a.language}&sample_rate={a.sample_rate}&decoding={a.decoding}&partials=true"
    async with websockets.connect(f"{ASR_WS}?{query}") as ws:
        ready = json.loads(await ws.recv())
        print("session", ready["session_id"], ready["config"]["vad"])

        # Optional: tune endpointing before sending any audio
        await ws.send(json.dumps({"type": "config", "vad": {"min_silence_ms": a.min_silence_ms}}))
        await ws.recv()                          # a second "ready" with the new config

        async def send_audio():
            t0 = time.perf_counter()
            for k, frame in enumerate(read_frames(a.file, a.sample_rate)):
                await ws.send(frame)             # binary frame = audio
                await asyncio.sleep(max(0.0, t0 + (k + 1) * 0.02 - time.perf_counter()))
            await ws.send(json.dumps({"type": "stop"}))   # flush the last utterance, then close

        async def receive():
            async for msg in ws:
                m = json.loads(msg)
                if m["type"] == "partial":
                    print(f"  ... {m['text']}")
                elif m["type"] == "final":
                    print(f"[{m['start_ms'] / 1000:.2f}-{m['end_ms'] / 1000:.2f}s] {m['text']}"
                          f"   (decoded in {m['decode_ms']} ms)")
                elif m["type"] in ("speech_start", "speech_end"):
                    print(f"<{m['type']} segment {m['segment_id']}>")
                elif m["type"] == "error":
                    print("error:", m["message"])
                elif m["type"] == "flushed":
                    return

        await asyncio.gather(send_audio(), receive())


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("file")
    p.add_argument("--language", required=True)
    p.add_argument("--sample-rate", type=int, default=16000, help="rate to send at; 8000 for telephony")
    p.add_argument("--decoding", default="rnnt", choices=["rnnt", "ctc"])
    p.add_argument("--min-silence-ms", type=int, default=500, help="pause that ends an utterance")
    asyncio.run(main(p.parse_args()))
