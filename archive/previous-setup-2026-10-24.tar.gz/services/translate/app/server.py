"""Streaming translation service (bodhan-ai/indic-translate on vLLM).

No longer deployed: translate now runs on an NVIDIA NIM (see docker-compose.yml and
docs/NIM_POC.md). This image still backs the `translate-vllm` fallback, which runs
`vllm serve` instead of this app.

The model's prompt contract (target language only, one user turn, no system
turn) is imported from the model repo's own ``scripts/prompt_contract.py`` so the
service can never drift from it.

HTTP
  GET  /health
  GET  /v1/languages
  POST /v1/translate     {"text": "...", "tgt_lang": "ta", "route": "direct"|"pivot", "stream": false}
                         or {"texts": [...], ...} for a batch; "stream": true returns SSE
WebSocket  /v1/stream
  client -> {"type": "translate", "id": "u1", "text": "...", "tgt_lang": "ta", "route": "direct"}
            {"type": "cancel", "id": "u1"}
  server -> {"type": "delta", "id": "u1", "text": "..."} ... {"type": "done", "id": "u1", ...}
  Requests on one socket run concurrently; match replies by id.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import time
import uuid
from typing import AsyncIterator

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("translate")

MODEL_DIR = os.environ.get("MODEL_DIR", "/models/indic-translate")
sys.path.insert(0, os.path.join(MODEL_DIR, "scripts"))
import prompt_contract  # noqa: E402  (shipped with the model)

# Short ISO codes used by the ASR and TTS services -> the model's FLORES-style codes.
ISO_TO_FLORES = {
    "en": "eng_Latn", "as": "asm_Beng", "bn": "ben_Beng", "brx": "brx_Deva", "doi": "doi_Deva",
    "gom": "gom_Deva", "kok": "gom_Deva", "gu": "guj_Gujr", "hi": "hin_Deva", "kn": "kan_Knda",
    "ks": "kas_Arab", "mai": "mai_Deva", "ml": "mal_Mlym", "mni": "mni_Mtei", "mr": "mar_Deva",
    "ne": "npi_Deva", "or": "ory_Orya", "pa": "pan_Guru", "sa": "san_Deva", "sat": "sat_Olck",
    "sd": "snd_Deva", "ta": "tam_Taml", "te": "tel_Telu", "ur": "urd_Arab",
}
ENGLISH = "English"

app = FastAPI(title="Indic Translate")
state: dict = {"ready": False}


def resolve(lang: str) -> str:
    """Any of 'ta', 'tam_Taml', 'Tamil', 'Hindi (Roman)' -> the prompt's language name."""
    key = ISO_TO_FLORES.get(lang.strip().lower(), lang)
    try:
        return prompt_contract.resolve_language(key)
    except ValueError:
        # the contract also accepts "(Roman)" / "(code-mixed)" variants of any name
        for suffix in (" (Roman)", " (code-mixed)"):
            if key.endswith(suffix):
                return prompt_contract.resolve_language(key[: -len(suffix)]) + suffix
        raise


@app.on_event("startup")
async def startup():
    from transformers import AutoTokenizer
    from vllm import AsyncEngineArgs
    from vllm.v1.engine.async_llm import AsyncLLM

    t0 = time.perf_counter()
    state["tok"] = AutoTokenizer.from_pretrained(MODEL_DIR)
    args = AsyncEngineArgs(
        model=MODEL_DIR,
        served_model_name="indic-translate",
        dtype="bfloat16",
        trust_remote_code=True,
        max_model_len=int(os.environ.get("MAX_MODEL_LEN", "4096")),
        gpu_memory_utilization=float(os.environ.get("GPU_MEMORY_UTILIZATION", "0.50")),
        max_num_seqs=int(os.environ.get("MAX_NUM_SEQS", "64")),
        # small prefill chunks: live requests are short, and the activation peak
        # (logits over a 157k-262k vocab) is what eats the KV-cache budget
        max_num_batched_tokens=int(os.environ.get("MAX_NUM_BATCHED_TOKENS", "1024")),
        enable_prefix_caching=True,
        language_model_only=True,          # text in, text out: skip the vision/audio towers
        enforce_eager=os.environ.get("ENFORCE_EAGER", "0") == "1",
    )
    state["engine"] = AsyncLLM.from_engine_args(args)
    state["max_model_len"] = args.max_model_len
    for tgt in ("Tamil", "Hindi", "English"):
        await translate_once("नमस्ते, आप कैसे हैं?", tgt, "direct", 64)
    # batched decoding JIT-compiles its own Triton kernels (a ~1 s spike if left to traffic)
    await asyncio.gather(*[translate_once("आज मौसम बहुत अच्छा है।", "Tamil", "direct", 32) for _ in range(8)])
    state["ready"] = True
    log.info("ready in %.1fs", time.perf_counter() - t0)


@app.on_event("shutdown")
async def shutdown():
    if "engine" in state:
        state["engine"].shutdown()


# ---------------------------------------------------------------------------- core
def prompt_ids(text: str, tgt_name: str) -> list[int]:
    tok = state["tok"]
    conv = [{"role": "user", "content": prompt_contract.TEMPLATE.replace("{tgt}", tgt_name).replace("{text}", text)}]
    rendered = tok.apply_chat_template(conv, add_generation_prompt=True, tokenize=False)
    return tok(rendered, add_special_tokens=False).input_ids   # template already has <bos>


async def generate(text: str, tgt_name: str, max_tokens: int | None, rid: str) -> AsyncIterator[tuple[str, dict]]:
    """Yield (delta_text, stats) pairs; stats is filled in on the last one."""
    from vllm import SamplingParams
    from vllm.inputs import TokensPrompt
    from vllm.sampling_params import RequestOutputKind

    ids = prompt_ids(text, tgt_name)
    src_tokens = len(state["tok"](text, add_special_tokens=False).input_ids)
    budget = state["max_model_len"] - len(ids)
    if budget <= 8:
        raise ValueError(f"input too long ({len(ids)} prompt tokens, limit {state['max_model_len']})")
    # Indic scripts can take ~2-3x the tokens of the source; cap runaway generations
    limit = min(budget, max_tokens or (4 * src_tokens + 32))
    sp = SamplingParams(temperature=0.0, max_tokens=limit, stop=prompt_contract.STOP_STRINGS,
                        output_kind=RequestOutputKind.DELTA, skip_special_tokens=True)
    t0 = time.perf_counter()
    ttft = None
    n_out = 0
    finish = None
    async for out in state["engine"].generate(TokensPrompt(prompt_token_ids=ids), sp, request_id=rid):
        o = out.outputs[0]
        n_out += len(o.token_ids)
        if ttft is None and o.token_ids:
            ttft = (time.perf_counter() - t0) * 1000
        if out.finished:
            finish = o.finish_reason
        yield o.text, {}
    yield "", {"ttft_ms": round(ttft or 0, 1), "latency_ms": round((time.perf_counter() - t0) * 1000, 1),
               "input_tokens": len(ids), "output_tokens": n_out, "finish_reason": finish}


async def translate_once(text: str, tgt_name: str, route: str, max_tokens: int | None,
                         rid: str | None = None) -> dict:
    parts, stats = [], {}
    async for delta, st in translate_stream(text, tgt_name, route, max_tokens, rid or uuid.uuid4().hex):
        parts.append(delta)
        stats = st or stats
    return {"translation": "".join(parts).strip(), **stats}


async def translate_stream(text: str, tgt_name: str, route: str, max_tokens: int | None,
                           rid: str) -> AsyncIterator[tuple[str, dict]]:
    """Direct: one call. Pivot: source -> English (collected), then English -> target (streamed)."""
    text = " ".join(text.split())
    if not text:
        yield "", {"latency_ms": 0.0}
        return
    t0 = time.perf_counter()
    extra: dict = {"route": route, "tgt_lang": tgt_name}
    if route == "pivot" and tgt_name != ENGLISH:
        pivot, st1 = [], {}
        async for d, st in generate(text, ENGLISH, max_tokens, rid + "-en"):
            pivot.append(d)
            st1 = st or st1
        text = "".join(pivot).strip()
        extra.update(pivot_text=text, pivot_latency_ms=st1.get("latency_ms"))
    async for d, st in generate(text, tgt_name, max_tokens, rid):
        if st:
            st = {**st, **extra, "latency_ms": round((time.perf_counter() - t0) * 1000, 1)}
            if route == "pivot":
                st["ttft_ms"] = round(st["ttft_ms"] + (extra.get("pivot_latency_ms") or 0), 1)
        yield d, st


# ---------------------------------------------------------------------------- HTTP
class TranslateRequest(BaseModel):
    text: str | None = None
    texts: list[str] | None = None
    tgt_lang: str
    src_lang: str | None = Field(None, description="informational; the model infers the source")
    route: str = Field("direct", pattern="^(direct|pivot)$")
    stream: bool = False
    max_tokens: int | None = Field(None, ge=1, le=8192)


@app.get("/health")
async def health():
    if not state["ready"]:
        return JSONResponse({"status": "loading"}, status_code=503)
    return {"status": "ok"}


@app.get("/v1/languages")
async def languages():
    return {"languages": prompt_contract.LANGUAGE_NAMES, "iso_aliases": ISO_TO_FLORES,
            "variants": ["<Name> (Roman)", "<Name> (code-mixed)"], "routes": ["direct", "pivot"]}


@app.post("/v1/translate")
async def translate(req: TranslateRequest):
    if not state["ready"]:
        raise HTTPException(503, "model loading")
    try:
        tgt = resolve(req.tgt_lang)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if (req.text is None) == (req.texts is None):
        raise HTTPException(400, "send exactly one of 'text' or 'texts'")
    if req.src_lang and resolve_or_none(req.src_lang) == ENGLISH:
        req.route = "direct"

    if req.texts is not None:
        try:
            results = await asyncio.gather(*[translate_once(t, tgt, req.route, req.max_tokens) for t in req.texts])
        except ValueError as e:
            raise HTTPException(400, str(e))
        return {"translations": results}

    if not req.stream:
        try:
            return await translate_once(req.text, tgt, req.route, req.max_tokens)
        except ValueError as e:
            raise HTTPException(400, str(e))

    rid = uuid.uuid4().hex

    async def sse():
        try:
            async for d, st in translate_stream(req.text, tgt, req.route, req.max_tokens, rid):
                if d:
                    yield f"data: {json.dumps({'type': 'delta', 'text': d}, ensure_ascii=False)}\n\n"
                if st:
                    yield f"data: {json.dumps({'type': 'done', **st}, ensure_ascii=False)}\n\n"
        except ValueError as e:
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"
        except asyncio.CancelledError:
            await state["engine"].abort([rid, rid + "-en"])
            raise

    return StreamingResponse(sse(), media_type="text/event-stream")


def resolve_or_none(lang: str) -> str | None:
    try:
        return resolve(lang)
    except ValueError:
        return None


# ---------------------------------------------------------------------------- WebSocket
@app.websocket("/v1/stream")
async def stream(ws: WebSocket):
    await ws.accept()
    if not state["ready"]:
        await ws.send_text(json.dumps({"type": "error", "message": "model loading"}))
        await ws.close(code=1013)
        return
    lock = asyncio.Lock()
    tasks: dict[str, tuple[asyncio.Task, str]] = {}

    async def send(msg: dict):
        async with lock:
            await ws.send_text(json.dumps(msg, ensure_ascii=False))

    async def run(cid: str, rid: str, text: str, tgt: str, route: str, max_tokens: int | None):
        try:
            full = []
            async for d, st in translate_stream(text, tgt, route, max_tokens, rid):
                if d:
                    full.append(d)
                    await send({"type": "delta", "id": cid, "text": d})
                if st:
                    await send({"type": "done", "id": cid, "translation": "".join(full).strip(), **st})
        except asyncio.CancelledError:
            await state["engine"].abort([rid, rid + "-en"])
            await send({"type": "cancelled", "id": cid})
        except Exception as e:  # noqa: BLE001
            log.exception("request %s failed", cid)
            await send({"type": "error", "id": cid, "message": str(e)})
        finally:
            tasks.pop(cid, None)

    await send({"type": "ready"})
    try:
        while True:
            try:
                msg = json.loads(await ws.receive_text())
            except json.JSONDecodeError:
                await send({"type": "error", "message": "messages must be JSON"})
                continue
            kind, cid = msg.get("type"), str(msg.get("id") or uuid.uuid4().hex[:8])
            if kind == "translate":
                try:
                    tgt = resolve(msg["tgt_lang"])
                    route = msg.get("route", "direct")
                    if route not in ("direct", "pivot"):
                        raise ValueError("route must be 'direct' or 'pivot'")
                except (KeyError, ValueError) as e:
                    await send({"type": "error", "id": cid, "message": f"bad request: {e}"})
                    continue
                if cid in tasks:
                    await send({"type": "error", "id": cid, "message": "id already in flight"})
                    continue
                rid = f"{cid}-{uuid.uuid4().hex[:8]}"
                tasks[cid] = (asyncio.create_task(run(cid, rid, msg.get("text", ""), tgt, route,
                                                      msg.get("max_tokens"))), rid)
            elif kind == "cancel":
                if cid in tasks:
                    tasks[cid][0].cancel()
            else:
                await send({"type": "error", "message": f"unknown message type {kind!r}"})
    except WebSocketDisconnect:
        pass
    finally:
        for task, _ in list(tasks.values()):
            task.cancel()
