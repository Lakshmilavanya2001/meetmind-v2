"""Streaming ASR service (IndicConformer-600M multilingual).

HTTP
  GET  /health                 200 once the model is loaded and warmed up
  GET  /v1/languages
  POST /v1/transcribe          one audio file -> text (long files are VAD-split)

WebSocket  /v1/stream
  client -> server   binary frames: raw PCM (default s16le mono at `sample_rate`)
                     text frames:   {"type": "config", ...}   (optional, before audio)
                                    {"type": "flush"}         close the current utterance now
                                    {"type": "stop"}          flush, then close
  server -> client   {"type": "ready"}, {"type": "speech_start"}, {"type": "partial"},
                     {"type": "speech_end"}, {"type": "final"}, {"type": "error"}
  See README.md for every field.
"""
from __future__ import annotations

import asyncio
import io
import json
import logging
import os
import time
import uuid

import numpy as np
import soundfile as sf
import soxr
from fastapi import FastAPI, File, HTTPException, Query, Request, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import JSONResponse

from .engine import LANGUAGES, SAMPLE_RATE, BatchingWorker, IndicConformer
from .vad import Segmenter, SegmenterConfig, SileroVAD

logging.basicConfig(level=os.environ.get("LOG_LEVEL", "INFO"),
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("asr")

MODEL_DIR = os.environ.get("MODEL_DIR", "/models/indic-conformer-600m")
DEFAULT_DECODING = os.environ.get("ASR_DEFAULT_DECODING", "rnnt")
PARTIAL_DECODING = os.environ.get("ASR_PARTIAL_DECODING", "ctc")
DEFAULT_PARTIAL_INTERVAL_MS = int(os.environ.get("ASR_PARTIAL_INTERVAL_MS", "500"))
# Partials re-encode the whole utterance so far; when the encoder queue is this deep,
# skip them so finals keep their latency (load shedding).
PARTIAL_SHED_QUEUE = int(os.environ.get("ASR_PARTIAL_SHED_QUEUE", "8"))
MAX_FILE_S = float(os.environ.get("ASR_MAX_FILE_S", "600"))

app = FastAPI(title="Indic ASR (IndicConformer-600M)")
state: dict = {"ready": False}


@app.on_event("startup")
async def startup():
    def load():
        enc_batch = int(os.environ.get("ASR_ENC_BATCH", "4"))
        rnnt_processes = int(os.environ.get("ASR_RNNT_PROCESSES", "2"))
        model = IndicConformer(MODEL_DIR,
                               gpu_mem_limit_gb=float(os.environ.get("ASR_GPU_MEM_GB", "6")),
                               fixed_batch=enc_batch,
                               fixed_seconds=float(os.environ.get("ASR_ENC_SECONDS", "16")),
                               rnnt_in_process=rnnt_processes == 0)
        worker = BatchingWorker(model, max_batch=enc_batch,
                                max_wait_ms=float(os.environ.get("ASR_BATCH_WAIT_MS", "5")),
                                rnnt_processes=rnnt_processes)
        vad = SileroVAD()
        # warm up the fixed encoder shape and both decoders
        for secs in (1, 6):
            for dec in ("ctc", "rnnt"):
                worker.submit(np.zeros(SAMPLE_RATE * secs, np.float32), "hi", dec).result()
        return model, worker, vad

    t0 = time.perf_counter()
    state["model"], state["worker"], state["vad"] = await asyncio.to_thread(load)
    state["ready"] = True
    log.info("ready in %.1fs", time.perf_counter() - t0)


@app.get("/health")
async def health():
    if not state["ready"]:
        return JSONResponse({"status": "loading"}, status_code=503)
    return {"status": "ok"}


@app.get("/v1/languages")
async def languages():
    return {"languages": LANGUAGES, "sample_rate": SAMPLE_RATE, "decodings": ["rnnt", "ctc"]}


def _check(lang: str, decoding: str):
    if lang not in LANGUAGES:
        raise ValueError(f"unsupported language {lang!r}; one of {LANGUAGES}")
    if decoding not in ("rnnt", "ctc"):
        raise ValueError("decoding must be 'rnnt' or 'ctc'")


def _to_16k_mono(data: np.ndarray, sr: int) -> np.ndarray:
    if data.ndim == 2:
        data = data.mean(axis=1)
    data = data.astype(np.float32, copy=False)
    return soxr.resample(data, sr, SAMPLE_RATE).astype(np.float32) if sr != SAMPLE_RATE else data


async def _transcribe(audio: np.ndarray, lang: str, decoding: str):
    return await asyncio.wrap_future(state["worker"].submit(audio, lang, decoding, final=True))


@app.post("/v1/transcribe")
async def transcribe(request: Request, file: UploadFile | None = File(None),
                     language: str = Query(...), decoding: str = Query(DEFAULT_DECODING),
                     sample_rate: int = Query(16000, description="only for raw PCM bodies"),
                     encoding: str = Query("wav", description="wav (any soundfile format) | pcm_s16le | pcm_f32le")):
    if not state["ready"]:
        raise HTTPException(503, "model loading")
    try:
        _check(language, decoding)
    except ValueError as e:
        raise HTTPException(400, str(e))
    raw = await file.read() if file is not None else await request.body()
    if not raw:
        raise HTTPException(400, "empty audio")
    try:
        if encoding == "pcm_s16le":
            data, sr = np.frombuffer(raw, np.int16).astype(np.float32) / 32768.0, sample_rate
        elif encoding == "pcm_f32le":
            data, sr = np.frombuffer(raw, np.float32), sample_rate
        else:
            data, sr = sf.read(io.BytesIO(raw), dtype="float32")
    except Exception as e:  # noqa: BLE001
        raise HTTPException(400, f"could not decode audio: {e}")
    audio = _to_16k_mono(data, sr)
    dur = len(audio) / SAMPLE_RATE
    if dur > MAX_FILE_S:
        raise HTTPException(413, f"audio longer than {MAX_FILE_S}s")

    t0 = time.perf_counter()
    if dur <= 15:
        segments = [(0, len(audio))]
    else:
        # long file: cut at pauses so every piece fits the encoder's fixed 16 s window
        seg = Segmenter(state["vad"], SegmenterConfig(max_segment_s=15, min_silence_ms=300))
        evs = seg.feed(audio) + seg.flush()
        segments = [(e.start_ms * 16, e.end_ms * 16) for e in evs if e.kind == "end"]
    results = await asyncio.gather(*[_transcribe(audio[a:b], language, decoding) for a, b in segments])
    return {
        "text": " ".join(r.text for r in results if r.text),
        "segments": [{"start_ms": a // 16, "end_ms": b // 16, "text": r.text}
                     for (a, b), r in zip(segments, results)],
        "language": language, "decoding": decoding, "duration_s": round(dur, 3),
        "processing_ms": round((time.perf_counter() - t0) * 1000, 1),
    }


# ---------------------------------------------------------------------------- streaming
class StreamSession:
    def __init__(self, ws: WebSocket, params: dict):
        self.ws = ws
        self.id = uuid.uuid4().hex[:12]
        self.send_lock = asyncio.Lock()
        self.configure(params)
        self.segment_id = 0
        self.partial_task: asyncio.Task | None = None
        self.final_chain: asyncio.Task | None = None
        self.last_partial_at = 0          # samples into the segment when the last partial was taken
        self.last_partial_text = ""
        self.received_samples = 0         # at the input rate

    def configure(self, p: dict):
        self.lang = p.get("language", "hi")
        self.decoding = p.get("decoding", DEFAULT_DECODING)
        self.partial_decoding = p.get("partial_decoding", PARTIAL_DECODING)
        _check(self.lang, self.decoding)
        _check(self.lang, self.partial_decoding)
        self.sample_rate = int(p.get("sample_rate", SAMPLE_RATE))
        self.encoding = p.get("encoding", "pcm_s16le")
        if self.encoding not in ("pcm_s16le", "pcm_f32le"):
            raise ValueError("encoding must be pcm_s16le or pcm_f32le")
        self.partials = bool(p.get("partials", True))
        self.partial_interval = int(p.get("partial_interval_ms", DEFAULT_PARTIAL_INTERVAL_MS)) * 16
        vad = p.get("vad", {})
        if isinstance(vad, bool):
            vad = {"enabled": vad}
        self.seg_cfg = SegmenterConfig(**{k: v for k, v in vad.items() if k in SegmenterConfig.__annotations__})
        # utterances must fit the encoder's fixed 16 s window (with VAD padding)
        self.seg_cfg.max_segment_s = min(float(self.seg_cfg.max_segment_s), 15.0)
        self.segmenter = Segmenter(state["vad"], self.seg_cfg)
        self.resampler = (soxr.ResampleStream(self.sample_rate, SAMPLE_RATE, 1, dtype="float32")
                          if self.sample_rate != SAMPLE_RATE else None)

    def describe(self) -> dict:
        c = self.seg_cfg
        return {"language": self.lang, "decoding": self.decoding, "partial_decoding": self.partial_decoding,
                "sample_rate": self.sample_rate, "encoding": self.encoding, "partials": self.partials,
                "partial_interval_ms": self.partial_interval // 16,
                "vad": {"enabled": c.enabled, "threshold": c.threshold, "min_silence_ms": c.min_silence_ms,
                        "speech_pad_ms": c.speech_pad_ms, "min_speech_ms": c.min_speech_ms,
                        "max_segment_s": c.max_segment_s}}

    async def send(self, msg: dict):
        async with self.send_lock:
            await self.ws.send_text(json.dumps(msg, ensure_ascii=False))

    def audio_from_bytes(self, b: bytes) -> np.ndarray:
        if self.encoding == "pcm_s16le":
            x = np.frombuffer(b[: len(b) // 2 * 2], np.int16).astype(np.float32) / 32768.0
        else:
            x = np.frombuffer(b[: len(b) // 4 * 4], np.float32)
        self.received_samples += len(x)
        if self.resampler is not None:
            x = self.resampler.resample_chunk(x)
        return x

    async def handle_events(self, events):
        for ev in events:
            if ev.kind == "start":
                self.segment_id += 1
                self.last_partial_at, self.last_partial_text = 0, ""
                await self.send({"type": "speech_start", "segment_id": self.segment_id, "start_ms": ev.start_ms})
            else:
                await self.send({"type": "speech_end", "segment_id": self.segment_id,
                                 "start_ms": ev.start_ms, "end_ms": ev.end_ms, "forced": ev.forced})
                self.queue_final(self.segment_id, ev)
        if self.partials:
            self.maybe_partial()

    def maybe_partial(self):
        audio = self.segmenter.current_audio()
        if audio is None or len(audio) - self.last_partial_at < self.partial_interval:
            return
        if self.partial_task is not None and not self.partial_task.done():
            return                      # one partial in flight per stream; skip, don't queue
        if state["worker"].q.qsize() >= PARTIAL_SHED_QUEUE:
            return
        self.last_partial_at = len(audio)
        self.partial_task = asyncio.create_task(self.run_partial(self.segment_id, audio))

    async def run_partial(self, seg_id: int, audio: np.ndarray):
        fut = state["worker"].submit(audio, self.lang, self.partial_decoding, final=False)
        try:
            r = await asyncio.wrap_future(fut)
        except Exception:  # noqa: BLE001 - a lost partial is harmless; the final will retry
            log.exception("partial decode failed (stream %s)", self.id)
            return
        # drop it if the utterance already ended (its final is coming) or nothing changed
        if seg_id == self.segment_id and self.segmenter.current_audio() is not None and r.text != self.last_partial_text:
            self.last_partial_text = r.text
            await self.send({"type": "partial", "segment_id": seg_id, "text": r.text,
                             "audio_ms": len(audio) // 16, "decode_ms": round(r.decode_ms, 1)})

    def queue_final(self, seg_id: int, ev):
        prev = self.final_chain
        t_end = time.perf_counter()

        async def run():
            fut = state["worker"].submit(ev.audio, self.lang, self.decoding, final=True)
            try:
                r = await asyncio.wrap_future(fut)
            except Exception as e:  # noqa: BLE001
                log.exception("final decode failed (stream %s, segment %d)", self.id, seg_id)
                r = e
            if prev is not None:
                await prev                   # finals go out in utterance order
            if isinstance(r, Exception):
                await self.send({"type": "error", "segment_id": seg_id, "message": f"decode failed: {r}"})
                return
            await self.send({"type": "final", "segment_id": seg_id, "text": r.text,
                             "start_ms": ev.start_ms, "end_ms": ev.end_ms, "forced": ev.forced,
                             "language": self.lang, "decoding": self.decoding,
                             "decode_ms": round(r.decode_ms, 1), "queue_ms": round(r.queue_ms, 1),
                             "batch_size": r.batch_size, "timings_ms": r.timings,
                             "latency_ms": round((time.perf_counter() - t_end) * 1000, 1)})

        self.final_chain = asyncio.create_task(run())

    async def drain(self):
        if self.final_chain is not None:
            await self.final_chain


@app.websocket("/v1/stream")
async def stream(ws: WebSocket):
    await ws.accept()
    if not state["ready"]:
        await ws.send_text(json.dumps({"type": "error", "message": "model loading"}))
        await ws.close(code=1013)
        return
    params = dict(ws.query_params)
    for k in ("partials",):
        if k in params:
            params[k] = params[k].lower() in ("1", "true", "yes")
    if "vad" in params:
        params["vad"] = params["vad"].lower() in ("1", "true", "yes")
    try:
        sess = StreamSession(ws, params)
    except (ValueError, TypeError) as e:
        await ws.send_text(json.dumps({"type": "error", "message": str(e)}))
        await ws.close(code=1003)
        return
    await sess.send({"type": "ready", "session_id": sess.id, "config": sess.describe()})
    log.info("stream %s opened %s", sess.id, sess.describe())
    got_audio = False
    try:
        while True:
            msg = await ws.receive()
            if msg["type"] == "websocket.disconnect":
                break
            if msg.get("bytes") is not None:
                got_audio = True
                await sess.handle_events(sess.segmenter.feed(sess.audio_from_bytes(msg["bytes"])))
                continue
            try:
                ctrl = json.loads(msg.get("text") or "{}")
            except json.JSONDecodeError:
                await sess.send({"type": "error", "message": "text frames must be JSON"})
                continue
            kind = ctrl.get("type")
            if kind == "config":
                if got_audio:
                    await sess.send({"type": "error", "message": "config must come before audio"})
                    continue
                try:
                    sess.configure({**params, **ctrl})
                except (ValueError, TypeError) as e:
                    await sess.send({"type": "error", "message": str(e)})
                    continue
                await sess.send({"type": "ready", "session_id": sess.id, "config": sess.describe()})
            elif kind in ("flush", "stop"):
                if sess.resampler is not None:
                    tail = sess.resampler.resample_chunk(np.zeros(0, np.float32), last=True)
                    sess.resampler = soxr.ResampleStream(sess.sample_rate, SAMPLE_RATE, 1, dtype="float32")
                    if len(tail):
                        await sess.handle_events(sess.segmenter.feed(tail))
                await sess.handle_events(sess.segmenter.flush())
                await sess.drain()
                await sess.send({"type": "flushed"})
                if kind == "stop":
                    await ws.close()
                    break
            else:
                await sess.send({"type": "error", "message": f"unknown message type {kind!r}"})
    except WebSocketDisconnect:
        pass
    except Exception as e:  # noqa: BLE001
        log.exception("stream %s failed", sess.id)
        try:
            await sess.send({"type": "error", "message": str(e)})
            await ws.close(code=1011)
        except Exception:  # noqa: BLE001
            pass
    finally:
        if sess.partial_task is not None:
            sess.partial_task.cancel()
        log.info("stream %s closed after %.1fs of audio", sess.id, sess.received_samples / max(sess.sample_rate, 1))
