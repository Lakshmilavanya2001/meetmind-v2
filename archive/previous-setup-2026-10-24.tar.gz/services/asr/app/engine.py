"""IndicConformer-600M inference engine with cross-request batching.

The released checkpoint is a set of ONNX graphs plus a TorchScript feature
extractor. This re-implements the decode loop of the model repo's
``model_onnx.py`` (outputs verified identical) with changes for serving:

* Every encoder call has one fixed shape (``fixed_batch`` x ``fixed_seconds``,
  padding masked by the length input). ONNX Runtime's CUDA Conv keeps its cuDNN
  setup for the last input shape only: a new shape costs ~85 ms across the
  encoder's 77 convs, a repeated one ~2 ms.
* The encoder batch mixes languages; the language only matters after encoding.
* The RNNT greedy search is batched (one ONNX call per step for every utterance
  still decoding) and runs on CPU in separate processes: it is hundreds of tiny
  calls per utterance, and in the server process it would hold the GIL that the
  WebSocket event loop needs.
"""
from __future__ import annotations

import json
import logging
import multiprocessing
import os
import queue
import threading
import time
from concurrent.futures import Future, ProcessPoolExecutor
from dataclasses import dataclass, field

import numpy as np
import onnxruntime as ort

log = logging.getLogger("asr.engine")

SAMPLE_RATE = 16_000
LANGUAGES = ["as", "bn", "brx", "doi", "gu", "hi", "kn", "kok", "ks", "mai", "ml",
             "mni", "mr", "ne", "or", "pa", "sa", "sat", "sd", "ta", "te", "ur"]


def _load_json(*parts):
    with open(os.path.join(*parts)) as f:
        return json.load(f)


# ---------------------------------------------------------------------------- RNNT (CPU)
def _batchable_rnnt_decoder(path: str) -> bytes:
    """The export declares the LSTM cell-state input as [2, 1, 640] (the hidden state
    is already [2, B, 640]); it only feeds Slice ops on the layer axis, so relaxing
    that one dim lets the prediction net run on a batch. Verified bit-identical to
    per-row calls."""
    import onnx

    m = onnx.load(path)
    for inp in m.graph.input:
        if inp.name == "onnx::Slice_3":
            dim = inp.type.tensor_type.shape.dim[1]
            dim.ClearField("dim_value")
            dim.dim_param = "B"
    return m.SerializeToString()


class RnntSearcher:
    """Batched greedy RNNT search over joint-encoder projections, on CPU."""

    def __init__(self, model_dir: str):
        cfg = _load_json(model_dir, "config.json")
        self.blank_id = cfg.get("BLANK_ID", 256)
        self.sos = cfg.get("SOS", 256)
        self.max_symbols = cfg.get("RNNT_MAX_SYMBOLS", 10)
        self.pred_layers = cfg.get("PRED_RNN_LAYERS", 2)
        self.pred_hidden = cfg.get("PRED_RNN_HIDDEN_DIM", 640)
        assets = os.path.join(model_dir, "assets")
        # a few tiny matmuls per call: a spinning thread pool costs more than the math
        so = ort.SessionOptions()
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        so.intra_op_num_threads = 1
        so.inter_op_num_threads = 1
        so.add_session_config_entry("session.intra_op.allow_spinning", "0")
        so.log_severity_level = 3
        cpu = ["CPUExecutionProvider"]

        def load(name):
            return ort.InferenceSession(os.path.join(assets, f"{name}.onnx"), so, providers=cpu)

        self.decoder = ort.InferenceSession(_batchable_rnnt_decoder(os.path.join(assets, "rnnt_decoder.onnx")),
                                            so, providers=cpu)
        self.joint_pred = load("joint_pred")
        self.joint_pre = load("joint_pre_net")
        self.joint_post = {lang: load(f"joint_post_net_{lang}") for lang in LANGUAGES}
        self.vocab = _load_json(assets, "vocab.json")

    def _predict(self, tokens: np.ndarray, h: np.ndarray, c: np.ndarray):
        """Prediction network for a batch of last tokens -> (joint-ready g [B,1,H], h', c')."""
        g_raw, _, h2, c2 = self.decoder.run(
            ["outputs", "prednet_lengths", "states", "162"],
            {"targets": tokens.reshape(-1, 1).astype(np.int32),
             "target_length": np.ones(len(tokens), np.int32),
             "states.1": np.ascontiguousarray(h), "onnx::Slice_3": np.ascontiguousarray(c)})
        return self.joint_pred.run(["output"], {"input": g_raw.transpose(0, 2, 1)})[0], h2, c2

    def search(self, f_all: np.ndarray, enc_len: np.ndarray, langs: list[str]) -> list[str]:
        """f_all: [B, T, H] joint-encoder projections. Every ONNX call serves all
        utterances still decoding, so B utterances cost about as much Python as one."""
        B = f_all.shape[0]
        lens = np.asarray(enc_len).astype(int)
        hyps: list[list[int]] = [[] for _ in range(B)]
        h = np.zeros((self.pred_layers, B, self.pred_hidden), np.float32)
        c = np.zeros_like(h)
        g, h_new, c_new = self._predict(np.full(B, self.sos), h, c)    # g only changes on emission
        groups: dict[str, list[int]] = {}
        for i, lang in enumerate(langs):
            groups.setdefault(lang, []).append(i)
        by_lang = {k: np.asarray(v) for k, v in groups.items()}

        for t in range(int(lens.max())):
            live = np.flatnonzero(lens > t)
            for _ in range(self.max_symbols):
                if len(live) == 0:
                    break
                joint = self.joint_pre.run(["output"], {"input": f_all[live, t: t + 1] + g[live]})[0]
                tok = np.empty(len(live), np.int64)
                for lang, members in by_lang.items():
                    sel = np.flatnonzero(np.isin(live, members))
                    if len(sel):
                        logits = self.joint_post[lang].run(["output"], {"input": joint[sel]})[0]
                        tok[sel] = logits.reshape(len(sel), -1).argmax(-1)
                emit = tok != self.blank_id
                live, tok = live[emit], tok[emit]
                if len(live) == 0:
                    break
                for i, k in zip(live, tok):
                    hyps[i].append(int(k))
                # the emitting rows commit the state computed for their previous token
                h[:, live], c[:, live] = h_new[:, live], c_new[:, live]
                g_up, h_up, c_up = self._predict(tok, h[:, live], c[:, live])
                g[live], h_new[:, live], c_new[:, live] = g_up, h_up, c_up

        return ["".join(self.vocab[lang][k] for k in hyps[i]).replace("▁", " ").strip()
                for i, lang in enumerate(langs)]


_proc_searcher: RnntSearcher | None = None


def _proc_init(model_dir: str):
    global _proc_searcher
    _proc_searcher = RnntSearcher(model_dir)


def _proc_search(f_all: np.ndarray, enc_len: np.ndarray, langs: list[str]) -> list[str]:
    return _proc_searcher.search(f_all, enc_len, langs)


def _proc_warm() -> int:
    _proc_searcher.search(np.zeros((1, 20, 640), np.float32), np.array([20]), ["hi"])
    time.sleep(0.5)          # stay busy so the pool starts a separate process for the next one
    return os.getpid()


# ---------------------------------------------------------------------------- encoder (GPU)
class IndicConformer:
    def __init__(self, model_dir: str, device: str = "cuda", gpu_mem_limit_gb: float = 8.0,
                 fixed_batch: int = 4, fixed_seconds: float = 16.0, rnnt_in_process: bool = True):
        import torch

        self.model_dir = model_dir
        self.fixed_batch = fixed_batch
        self.fixed_samples = int(fixed_seconds * SAMPLE_RATE)
        assets = os.path.join(model_dir, "assets")
        cfg = _load_json(model_dir, "config.json")
        self.blank_id = cfg.get("BLANK_ID", 256)

        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.preprocessor = torch.jit.load(os.path.join(assets, "preprocessor.ts"), map_location=self.device)

        so = ort.SessionOptions()
        so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
        so.log_severity_level = 3
        gpu = ("CUDAExecutionProvider", {
            "device_id": self.device.index or 0,
            "cudnn_conv_algo_search": "HEURISTIC",
            "arena_extend_strategy": "kSameAsRequested",
            "gpu_mem_limit": int(gpu_mem_limit_gb * (1 << 30)),
        })
        providers = [gpu, "CPUExecutionProvider"] if self.device.type == "cuda" else ["CPUExecutionProvider"]

        t0 = time.perf_counter()
        self.encoder = ort.InferenceSession(os.path.join(assets, "encoder.onnx"), so, providers=providers)
        self.ctc = ort.InferenceSession(os.path.join(assets, "ctc_decoder.onnx"), so, providers=providers)
        self.joint_enc = ort.InferenceSession(os.path.join(assets, "joint_enc.onnx"), so, providers=providers)
        self.rnnt = RnntSearcher(model_dir) if rnnt_in_process else None
        log.info("ONNX graphs loaded in %.1fs (encoder providers=%s)",
                 time.perf_counter() - t0, self.encoder.get_providers())

        self.vocab = _load_json(assets, "vocab.json")
        self.masks = {k: np.asarray(v, dtype=bool) for k, v in _load_json(assets, "language_masks.json").items()}

    def encode(self, wavs: list[np.ndarray]) -> tuple[np.ndarray, np.ndarray]:
        """-> encoder output and lengths; may hold extra (padding) rows after len(wavs)."""
        import torch

        lengths = np.array([len(w) for w in wavs], dtype=np.int64)
        if self.fixed_samples and len(wavs) <= self.fixed_batch and lengths.max() <= self.fixed_samples:
            shape = (self.fixed_batch, self.fixed_samples)
            lengths = np.concatenate([lengths, np.full(self.fixed_batch - len(wavs), SAMPLE_RATE // 10)])
        else:   # oversized request: correct, just pays the new-shape cost
            shape = (len(wavs), int(lengths.max()))
        batch = np.zeros(shape, dtype=np.float32)
        for i, w in enumerate(wavs):
            batch[i, : len(w)] = w
        with torch.inference_mode():
            feats, feat_len = self.preprocessor(input_signal=torch.from_numpy(batch).to(self.device),
                                                length=torch.from_numpy(lengths).to(self.device))
            feats, feat_len = feats.cpu().numpy(), feat_len.cpu().numpy()
        out, enc_len = self.encoder.run(["outputs", "encoded_lengths"], {"audio_signal": feats, "length": feat_len})
        return out, np.asarray(enc_len).reshape(-1)

    def ctc_decode(self, enc: np.ndarray, enc_len: np.ndarray, langs: list[str | None]) -> list[str | None]:
        """Rows with lang None are skipped. Pass every encoder row: the CTC head is a
        Conv too, so it should see the same fixed shape as the encoder."""
        logits = self.ctc.run(["logprobs"], {"encoder_output": enc})[0]   # B x T x V
        texts: list[str | None] = []
        for i, lang in enumerate(langs):
            if lang is None:
                texts.append(None)
                continue
            # argmax over the language's sub-vocabulary == argmax of its log_softmax
            ids = logits[i, : int(enc_len[i])][:, self.masks[lang]].argmax(-1)
            keep = np.ones(len(ids), dtype=bool)
            keep[1:] = ids[1:] != ids[:-1]
            vocab = self.vocab[lang]
            texts.append("".join(vocab[t] for t in ids[keep] if t != self.blank_id).replace("▁", " ").strip())
        return texts

    def joint_encode(self, enc: np.ndarray) -> np.ndarray:
        """Encoder output [B, D, T] -> joint-network encoder projection [B, T, H] (GPU)."""
        return self.joint_enc.run(["output"], {"input": enc.transpose(0, 2, 1)})[0]

    def transcribe_batch(self, wavs: list[np.ndarray], langs: list[str], decodings: list[str]) -> list[str]:
        """Synchronous, in-process path (tests and tools)."""
        enc, enc_len = self.encode(wavs)
        out: list[str | None] = [None] * len(wavs)
        if "ctc" in decodings:
            rows = [lang if d == "ctc" else None for lang, d in zip(langs, decodings)]
            for i, text in enumerate(self.ctc_decode(enc, enc_len, rows + [None] * (len(enc) - len(rows)))[: len(wavs)]):
                if text is not None:
                    out[i] = text
        idx = [i for i, d in enumerate(decodings) if d == "rnnt"]
        if idx:
            texts = self.rnnt.search(self.joint_encode(enc[idx]), enc_len[idx], [langs[i] for i in idx])
            for i, text in zip(idx, texts):
                out[i] = text
        return out  # type: ignore[return-value]


# ---------------------------------------------------------------------------- serving
@dataclass(order=True)
class _Job:
    priority: int                       # 0 = final, 1 = partial (finals jump the queue)
    seq: int
    audio: np.ndarray = field(compare=False)
    lang: str = field(compare=False)
    decoding: str = field(compare=False)
    future: Future = field(compare=False)
    enqueued: float = field(compare=False, default_factory=time.perf_counter)


@dataclass
class Result:
    text: str
    decode_ms: float        # from the start of its encoder batch to the result
    queue_ms: float         # waiting for an encoder batch
    batch_size: int         # encoder batch
    timings: dict           # encode / ctc / rnnt (ms) and batch sizes


@dataclass
class _RnntItem:
    f: np.ndarray            # [T, H] joint-encoder projection
    length: int
    job: _Job
    started: float           # when its encoder batch started
    timings: dict


class BatchingWorker:
    """Two-stage pipeline.

    Stage 1 (GPU thread): collects up to ``max_batch`` requests within
    ``max_wait_ms``, runs them as one fixed-shape encoder batch, answers CTC
    requests directly and hands RNNT requests to stage 2.
    Stage 2: whenever one of ``rnnt_processes`` search processes is free, every
    RNNT request waiting (from any number of encoder batches) goes to it as one
    batched search. ``rnnt_processes=0`` searches in a thread of this process.
    """

    def __init__(self, model: IndicConformer, max_batch: int = 4, max_wait_ms: float = 5.0,
                 max_batch_audio_s: float = 64.0, max_rnnt_batch: int = 32, rnnt_processes: int = 2):
        self.model = model
        self.max_batch = max_batch
        self.max_wait = max_wait_ms / 1000
        self.max_batch_samples = int(max_batch_audio_s * SAMPLE_RATE)
        self.max_rnnt_batch = max_rnnt_batch
        self.q: queue.PriorityQueue[_Job] = queue.PriorityQueue()
        self.rnnt_q: queue.Queue[_RnntItem] = queue.Queue()
        self._seq = 0
        self._lock = threading.Lock()
        if rnnt_processes > 0:
            self.pool = ProcessPoolExecutor(rnnt_processes, mp_context=multiprocessing.get_context("spawn"),
                                            initializer=_proc_init, initargs=(model.model_dir,))
            pids = {f.result() for f in [self.pool.submit(_proc_warm) for _ in range(rnnt_processes)]}
            log.info("RNNT search processes ready: %s", sorted(pids))
            self.slots = threading.Semaphore(rnnt_processes)
        else:
            self.pool, self.slots = None, threading.Semaphore(1)
            if model.rnnt is None:
                model.rnnt = RnntSearcher(model.model_dir)
        threading.Thread(target=self._encode_loop, name="asr-encoder", daemon=True).start()
        threading.Thread(target=self._rnnt_loop, name="asr-rnnt", daemon=True).start()

    def submit(self, audio: np.ndarray, lang: str, decoding: str, final: bool = True) -> Future:
        fut: Future = Future()
        with self._lock:
            self._seq += 1
            seq = self._seq
        self.q.put(_Job(0 if final else 1, seq, audio, lang, decoding, fut))
        return fut

    def _collect(self) -> list[_Job]:
        jobs = [self.q.get()]
        deadline = time.perf_counter() + self.max_wait
        total = len(jobs[0].audio)
        while len(jobs) < self.max_batch:
            timeout = deadline - time.perf_counter()
            if timeout <= 0:
                break
            try:
                nxt = self.q.get(timeout=timeout)
            except queue.Empty:
                break
            if total + len(nxt.audio) > self.max_batch_samples:
                self.q.put(nxt)
                break
            jobs.append(nxt)
            total += len(nxt.audio)
        return jobs

    def _encode_loop(self):
        m = self.model
        while True:
            jobs = self._collect()
            t0 = time.perf_counter()
            timings: dict = {"batch": len(jobs), "audio_s": round(sum(len(j.audio) for j in jobs) / SAMPLE_RATE, 2)}
            try:
                enc, enc_len = m.encode([j.audio for j in jobs])
                timings["encode"] = round((time.perf_counter() - t0) * 1000, 1)
                if any(j.decoding == "ctc" for j in jobs):
                    t = time.perf_counter()
                    rows = [j.lang if j.decoding == "ctc" else None for j in jobs]
                    texts = m.ctc_decode(enc, enc_len, rows + [None] * (len(enc) - len(rows)))
                    timings["ctc"] = round((time.perf_counter() - t) * 1000, 1)
                    for j, text in zip(jobs, texts):
                        if text is not None:
                            self._finish(j, text, t0, timings)
                idx = [i for i, j in enumerate(jobs) if j.decoding == "rnnt"]
                if idx:
                    f_all = m.joint_encode(enc[idx])
                    for k, i in enumerate(idx):
                        self.rnnt_q.put(_RnntItem(f_all[k], int(enc_len[i]), jobs[i], t0, timings))
            except Exception as e:  # noqa: BLE001 - surface any model error to every caller
                log.exception("encoder batch failed")
                for j in jobs:
                    if not j.future.done():
                        j.future.set_exception(e)

    def _rnnt_loop(self):
        while True:
            self.slots.acquire()                  # wait for a free search process...
            items = [self.rnnt_q.get()]           # ...then take everything that is waiting
            while len(items) < self.max_rnnt_batch:
                try:
                    items.append(self.rnnt_q.get_nowait())
                except queue.Empty:
                    break
            T = max(it.f.shape[0] for it in items)
            f_all = np.zeros((len(items), T, items[0].f.shape[1]), np.float32)
            for k, it in enumerate(items):
                f_all[k, : it.f.shape[0]] = it.f
            lens = np.array([it.length for it in items])
            langs = [it.job.lang for it in items]
            t = time.perf_counter()
            if self.pool is not None:
                fut = self.pool.submit(_proc_search, f_all, lens, langs)
                fut.add_done_callback(lambda f, items=items, t=t: self._rnnt_done(items, f, t))
            else:
                fut = Future()
                try:
                    fut.set_result(self.model.rnnt.search(f_all, lens, langs))
                except Exception as e:  # noqa: BLE001
                    fut.set_exception(e)
                self._rnnt_done(items, fut, t)

    def _rnnt_done(self, items: list[_RnntItem], fut: Future, t: float):
        self.slots.release()
        dt = round((time.perf_counter() - t) * 1000, 1)
        try:
            texts = fut.result()
        except Exception as e:  # noqa: BLE001
            log.exception("rnnt search failed")
            for it in items:
                if not it.job.future.done():
                    it.job.future.set_exception(e)
            return
        for it, text in zip(items, texts):
            self._finish(it.job, text, it.started, {**it.timings, "rnnt": dt, "rnnt_batch": len(items)})

    @staticmethod
    def _finish(job: _Job, text: str, started: float, timings: dict):
        job.future.set_result(Result(text, (time.perf_counter() - started) * 1000,
                                     (started - job.enqueued) * 1000, timings["batch"], timings))
