"""Stream an audio file to the ASR service as if it were a live microphone.

    .venv/bin/python clients/asr_stream.py testdata/sample_hindi.wav --language hi
    .venv/bin/python clients/asr_stream.py call.wav --language ta --sample-rate 8000 --speed 0

--speed 1 sends in real time (20 ms frames); --speed 0 sends as fast as possible.
"""
import argparse
import asyncio
import json
import time

import numpy as np
import soundfile as sf
import websockets


async def main(a):
    audio, sr = sf.read(a.file, dtype="float32")
    if audio.ndim == 2:
        audio = audio.mean(1)
    if a.sample_rate and a.sample_rate != sr:
        import soxr
        audio, sr = soxr.resample(audio, sr, a.sample_rate), a.sample_rate
    pcm = (np.clip(audio, -1, 1) * 32767).astype("<i2")
    # trailing silence so the VAD can see the end of the last utterance
    pcm = np.concatenate([pcm, np.zeros(int(sr * a.tail_silence), "<i2")])
    frame = sr * 20 // 1000
    url = (f"{a.url}?language={a.language}&sample_rate={sr}&decoding={a.decoding}"
           f"&partials={'true' if not a.no_partials else 'false'}")
    t_start = time.perf_counter()
    last_audio_sent = {}

    async with websockets.connect(url, max_size=None) as ws:
        print(await ws.recv())

        async def sender():
            for i in range(0, len(pcm), frame):
                await ws.send(pcm[i: i + frame].tobytes())
                last_audio_sent["ms"] = (i + frame) * 1000 // sr
                if a.speed > 0:
                    target = t_start + (i + frame) / sr / a.speed
                    await asyncio.sleep(max(0, target - time.perf_counter()))
            await ws.send(json.dumps({"type": "stop"}))

        async def receiver():
            async for msg in ws:
                m = json.loads(msg)
                wall = (time.perf_counter() - t_start) * 1000
                if m["type"] == "final":
                    # with --speed 1, wall clock minus the utterance's end is the user-visible delay
                    lag = wall - m["end_ms"] / a.speed if a.speed > 0 else float("nan")
                    print(f"[{wall:7.0f} ms] FINAL  seg {m['segment_id']} {m['start_ms']}-{m['end_ms']} ms "
                          f"decode {m['decode_ms']} ms, end-of-audio->final {lag:.0f} ms\n    {m['text']}")
                elif m["type"] == "partial":
                    print(f"[{wall:7.0f} ms] partial seg {m['segment_id']}: {m['text']}")
                else:
                    print(f"[{wall:7.0f} ms] {m}")
                if m["type"] == "flushed":
                    return

        await asyncio.gather(sender(), receiver())


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("file")
    p.add_argument("--url", default="ws://localhost:8001/v1/stream")
    p.add_argument("--language", default="hi")
    p.add_argument("--decoding", default="rnnt")
    p.add_argument("--sample-rate", type=int, default=0, help="resample the file before sending (e.g. 8000)")
    p.add_argument("--speed", type=float, default=1.0)
    p.add_argument("--tail-silence", type=float, default=1.0)
    p.add_argument("--no-partials", action="store_true")
    asyncio.run(main(p.parse_args()))
