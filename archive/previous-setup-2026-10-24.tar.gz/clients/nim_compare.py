"""Compare two servers running bodhan-ai/indic-translate: outputs and latency.

    .venv/bin/python clients/nim_compare.py service --out baseline.json   # the custom translate service
    .venv/bin/python clients/nim_compare.py nim --out nim.json            # any OpenAI-compatible server
    .venv/bin/python clients/nim_compare.py diff baseline.json nim.json

Used for docs/NIM_POC.md, when the custom service (services/translate, POST
/v1/translate) ran on :8002 and the NIM on :8000. The NIM now serves :8002.
Set SERVICE_URL / NIM_URL to point the modes elsewhere.

Both get the same requests: the model's prompt contract (target language only,
one user turn), greedy decoding, streaming. Latency is measured client-side:
first text and full translation, one request at a time, then at concurrency 8 and 32.
"""
import argparse
import asyncio
import difflib
import json
import os
import statistics
import time

import httpx

SERVICE = os.environ.get("SERVICE_URL", "http://localhost:8002")
NIM = os.environ.get("NIM_URL", "http://localhost:8002")
TEMPLATE = "Translate the following text into {tgt}:\n\n{text}"     # from the model's prompt_contract.py
NAMES = {"ta": "Tamil", "hi": "Hindi", "te": "Telugu", "bn": "Bengali", "mr": "Marathi",
         "gu": "Gujarati", "kn": "Kannada", "ml": "Malayalam", "en": "English"}

SOURCES = [
    ("hi", "नमस्ते, आज हम गणित की कक्षा शुरू करेंगे, कृपया अपनी पुस्तकें खोलिए।"),
    ("hi", "कल सुबह दस बजे मैं आपको फ़ोन करूँगा।"),
    ("ta", "நாளை காலை பத்து மணிக்கு மருத்துவரைப் பார்க்க வேண்டும்."),
    ("te", "మీరు ఈ రోజు సాయంత్రం ఆఫీసుకు వస్తారా?"),
    ("bn", "আমার ট্রেন এক ঘণ্টা দেরিতে চলছে, আমি একটু পরে পৌঁছাব।"),
    ("mr", "मला उद्या बँकेत जायचे आहे, तुम्ही माझ्यासोबत याल का?"),
    ("gu", "તમારો ઓર્ડર આવતીકાલે સાંજ સુધીમાં પહોંચી જશે."),
    ("kn", "ನಾಳೆ ಬೆಳಿಗ್ಗೆ ಹತ್ತು ಗಂಟೆಗೆ ನಾನು ನಿಮಗೆ ಕರೆ ಮಾಡುತ್ತೇನೆ."),
]
TARGETS = {"hi": ["ta", "en", "kn"], "ta": ["hi", "en", "te"], "te": ["hi", "ta", "en"],
           "bn": ["hi", "en", "mr"], "mr": ["hi", "gu", "en"], "gu": ["hi", "mr", "en"],
           "kn": ["ml", "hi", "en"]}
ITEMS = [(src, tgt, text) for src, text in SOURCES for tgt in TARGETS[src]][:24]


async def stream_service(client, text, tgt):
    """Our service: POST /v1/translate with stream=true (Server-Sent Events)."""
    t0 = time.perf_counter()
    first, parts = None, []
    async with client.stream("POST", f"{SERVICE}/v1/translate",
                             json={"text": text, "tgt_lang": tgt, "stream": True}) as r:
        async for line in r.aiter_lines():
            if not line.startswith("data: "):
                continue
            ev = json.loads(line[6:])
            if ev["type"] == "delta" and ev["text"]:
                first = first or time.perf_counter()
                parts.append(ev["text"])
            elif ev["type"] == "error":
                raise RuntimeError(ev["message"])
    return "".join(parts).strip(), first - t0, time.perf_counter() - t0


async def stream_nim(client, text, tgt, model):
    """NIM: OpenAI chat completions, same prompt, greedy, streamed."""
    body = {"model": model, "stream": True, "temperature": 0, "max_tokens": 512, "stop": ["<turn|>"],
            "messages": [{"role": "user", "content": TEMPLATE.replace("{tgt}", NAMES[tgt]).replace("{text}", text)}]}
    t0 = time.perf_counter()
    first, parts = None, []
    async with client.stream("POST", f"{NIM}/v1/chat/completions", json=body) as r:
        if r.status_code != 200:
            raise RuntimeError(f"HTTP {r.status_code}: {(await r.aread())[:300]!r}")
        async for line in r.aiter_lines():
            if not line.startswith("data: ") or line == "data: [DONE]":
                continue
            delta = json.loads(line[6:])["choices"][0]["delta"].get("content")
            if delta:
                first = first or time.perf_counter()
                parts.append(delta)
    return "".join(parts).strip(), first - t0, time.perf_counter() - t0


async def run(target, out):
    async with httpx.AsyncClient(timeout=120) as client:
        model = None
        if target == "nim":
            model = (await client.get(f"{NIM}/v1/models")).json()["data"][0]["id"]
        call = (lambda t, g: stream_service(client, t, g)) if target == "service" else \
               (lambda t, g: stream_nim(client, t, g, model))
        for _ in range(3):                                   # warm-up
            await call(*ITEMS[0][2:0:-1])
        results = []
        for src, tgt, text in ITEMS:                         # one at a time
            out_text, ttft, total = await call(text, tgt)
            results.append({"src": src, "tgt": tgt, "text": text, "translation": out_text,
                            "ttft_ms": round(ttft * 1000, 1), "total_ms": round(total * 1000, 1)})
        conc = {}
        for n in (8, 32):
            jobs = [ITEMS[i % len(ITEMS)] for i in range(n)]
            t0 = time.perf_counter()
            res = await asyncio.gather(*[call(text, tgt) for _, tgt, text in jobs])
            wall = time.perf_counter() - t0
            conc[n] = {"ttft_p50_ms": round(statistics.median(r[1] for r in res) * 1000, 1),
                       "total_p50_ms": round(statistics.median(r[2] for r in res) * 1000, 1),
                       "total_max_ms": round(max(r[2] for r in res) * 1000, 1),
                       "sentences_per_s": round(n / wall, 1)}
    summary = {"target": target, "model": model,
               "ttft_p50_ms": statistics.median(r["ttft_ms"] for r in results),
               "total_p50_ms": statistics.median(r["total_ms"] for r in results),
               "concurrency": conc}
    json.dump({"summary": summary, "results": results}, open(out, "w"), ensure_ascii=False, indent=1)
    print(json.dumps(summary, indent=1))


def diff(a_path, b_path):
    a, b = json.load(open(a_path)), json.load(open(b_path))
    same, ratios = 0, []
    for ra, rb in zip(a["results"], b["results"]):
        r = difflib.SequenceMatcher(None, ra["translation"], rb["translation"]).ratio()
        ratios.append(r)
        same += ra["translation"] == rb["translation"]
        if ra["translation"] != rb["translation"]:
            print(f"- {ra['src']}->{ra['tgt']} ({r:.2f})\n    {a['summary']['target']}: {ra['translation']}\n"
                  f"    {b['summary']['target']}: {rb['translation']}")
    print(f"\nidentical outputs: {same}/{len(ratios)}, mean character similarity {statistics.mean(ratios):.3f}")
    sa, sb = a["summary"], b["summary"]
    print(f"{'':22s}{sa['target']:>12s}{sb['target']:>12s}")
    print(f"{'first text p50 (ms)':22s}{sa['ttft_p50_ms']:>12.0f}{sb['ttft_p50_ms']:>12.0f}")
    print(f"{'sentence p50 (ms)':22s}{sa['total_p50_ms']:>12.0f}{sb['total_p50_ms']:>12.0f}")
    for n in ("8", "32"):
        ca, cb = sa["concurrency"][n], sb["concurrency"][n]
        print(f"{'conc ' + n + ' sentence p50':22s}{ca['total_p50_ms']:>12.0f}{cb['total_p50_ms']:>12.0f}")
        print(f"{'conc ' + n + ' sentences/s':22s}{ca['sentences_per_s']:>12.1f}{cb['sentences_per_s']:>12.1f}")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("mode", choices=["service", "nim", "diff"])
    p.add_argument("files", nargs="*")
    p.add_argument("--out", default="compare.json")
    a = p.parse_args()
    if a.mode == "diff":
        diff(*a.files)
    else:
        asyncio.run(run(a.mode, a.out))
