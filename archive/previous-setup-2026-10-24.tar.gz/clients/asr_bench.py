"""N concurrent real-time ASR streams; reports how long finals take after speech ends.

    .venv/bin/python clients/asr_bench.py testdata/sample_hindi.wav --streams 1 8 16 32

Streams start staggered over --stagger seconds (calls don't all end their
sentences at the same instant); --stagger 0 is the synchronized worst case.
"""
import argparse
import asyncio
import json
import random
import statistics
import time

import numpy as np
import soundfile as sf
import websockets


async def one_stream(url, pcm, sr, delay, speech_pad_ms):
    await asyncio.sleep(delay)
    frame = sr * 20 // 1000
    finals, vad_lags = [], []
    async with websockets.connect(url, max_size=None) as ws:
        await ws.recv()
        t0 = time.perf_counter()

        async def sender():
            for i in range(0, len(pcm), frame):
                await ws.send(pcm[i: i + frame].tobytes())
                await asyncio.sleep(max(0, t0 + (i + frame) / sr - time.perf_counter()))
            await ws.send(json.dumps({"type": "stop"}))

        async def receiver():
            async for msg in ws:
                m = json.loads(msg)
                if m["type"] == "final":
                    # end_ms includes the server's trailing speech pad; add it back so this is
                    # "speaker stopped -> final transcript"
                    finals.append({"lag_ms": (time.perf_counter() - t0) * 1000 - m["end_ms"] + speech_pad_ms,
                                   "decode_ms": m["decode_ms"], "batch": m["batch_size"], "text": m["text"],
                                   "timings": m.get("timings_ms"), "queue_ms": m.get("queue_ms", 0),
                                   "vad_lag_ms": vad_lags[-1] if vad_lags else None})
                elif m["type"] == "speech_end":
                    # arrives ~min_silence after the speaker stops unless the server is behind on audio
                    vad_lags.append((time.perf_counter() - t0) * 1000 - m["end_ms"] + speech_pad_ms)
                elif m["type"] == "error":
                    finals.append({"error": m["message"]})
                elif m["type"] == "flushed":
                    return

        await asyncio.gather(sender(), receiver())
    return finals


async def main(a):
    audio, sr = sf.read(a.file, dtype="float32")
    pcm = np.concatenate([(np.clip(audio, -1, 1) * 32767).astype("<i2"), np.zeros(sr, "<i2")])
    url = f"{a.url}?language={a.language}&sample_rate={sr}&decoding={a.decoding}&partials={str(not a.no_partials).lower()}"
    for n in a.streams:
        random.seed(n)
        res = await asyncio.gather(*[one_stream(url, pcm, sr, random.uniform(0, a.stagger), a.speech_pad) for _ in range(n)],
                                   return_exceptions=True)
        finals = [f for r in res if isinstance(r, list) for f in r]
        errors = [r for r in res if isinstance(r, Exception)] + [f for f in finals if "error" in f]
        ok = [f for f in finals if "error" not in f]
        lag = [f["lag_ms"] for f in ok]
        dec = [f["decode_ms"] for f in ok]
        texts = {f["text"] for f in ok}
        print(f"{n:3d} streams: {len(ok)} finals, {len(errors)} errors | speech end -> final p50 {statistics.median(lag):5.0f} ms "
              f"max {max(lag):5.0f} ms (incl. {a.min_silence} ms VAD pause) | decode p50 {statistics.median(dec):4.0f} ms "
              f"max {max(dec):4.0f} ms | max batch {max(f['batch'] for f in ok)} | distinct texts {len(texts)}")
        vl = [f["vad_lag_ms"] for f in ok if f["vad_lag_ms"] is not None]
        print(f"     speech end -> speech_end event p50 {statistics.median(vl):.0f} ms max {max(vl):.0f} ms | "
              f"queue p50 {statistics.median(f['queue_ms'] for f in ok):.0f} ms max {max(f['queue_ms'] for f in ok):.0f} ms")
        if a.verbose:
            for f in ok[:3]:
                print("     batch timings:", f["timings"])
        if errors:
            print("     first error:", errors[0])


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("file")
    p.add_argument("--url", default="ws://localhost:8001/v1/stream")
    p.add_argument("--language", default="hi")
    p.add_argument("--decoding", default="rnnt")
    p.add_argument("--streams", type=int, nargs="+", default=[1, 8, 16, 32])
    p.add_argument("--stagger", type=float, default=0.0)
    p.add_argument("--min-silence", type=int, default=500, help="server VAD pause, for the printout only")
    p.add_argument("--speech-pad", type=int, default=200, help="server speech_pad_ms (trailing pad in end_ms)")
    p.add_argument("--no-partials", action="store_true")
    p.add_argument("--verbose", action="store_true")
    asyncio.run(main(p.parse_args()))
